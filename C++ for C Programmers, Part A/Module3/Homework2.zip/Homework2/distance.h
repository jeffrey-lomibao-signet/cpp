#ifndef DISTANCE_H
#define DISTANCE_H

#include <limits>
using namespace std;

using Distance = double;
constexpr Distance MAX_DISTANCE = numeric_limits<Distance>::max();

#endif
